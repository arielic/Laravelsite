<?php

namespace App\Http\Controllers;
use App\Models\expmodel;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
class srchctrl extends Controller
{
  public function index()
  {
      return view('search');
  }
 public function search(Request $request)
 {
     $queries = explode("\n", $request->input('text')); 
     //$keyword = $request->input('keyword');

     $results = expmodel::where(function ($query) use ($queries) {
         $query->where('codemelli', 'LIKE', "%$queries%")
               ->orWhere('name', 'LIKE', "%$queries%")
               ->orWhere('famil', 'LIKE', "%$queries%")
               ->orWhere('other', 'LIKE', "%$queries%");
     })->get();


     Excel::download('Search Results', function ($excel) use ($results) {
        $excel->sheet('Sheet 1', function ($sheet) use ($results) {
            $sheet->fromArray($results);
        });
    })->export('xlsx');
     // Export the results to an Excel file
    
 }
}
/*

 Excel::create('Search Results', function ($excel) use ($results) {
         $excel->sheet('Sheet 1', function ($sheet) use ($results) {
             $sheet->fromArray($results);
         });
     })->export('xlsx');
namespace App\Http\Controllers;

  use Illuminate\Http\Request;
  use Maatwebsite\Excel\Facades\Excel;
  use App\Models\expmodel; // Replace with your actual model
  class srchctrl extends Controller
  {
    public function index()
    {
        return view('search');
    }
   public function search(Request $request)
   {
       $queries = explode("\n", $request->input('query')); 
       //$keyword = $request->input('keyword');

       $results = expmodel::where(function ($query) use ($queries) {
           $query->where('codemelli', 'LIKE', "%$queries%")
                 ->orWhere('name', 'LIKE', "%$queries%")
                 ->orWhere('famil', 'LIKE', "%$queries%")
                 ->orWhere('other', 'LIKE', "%$queries%");
       })->get();

       // Export the results to an Excel file
       Excel::create('Search Results', function ($excel) use ($results) {
           $excel->sheet('Sheet 1', function ($sheet) use ($results) {
               $sheet->fromArray($results);
           });
       })->export('xlsx');
   }
}

lass srchctrl extends Controller
{

    public function index()
    {
        return view('search');
    }
public function search(Request $request)
{
    $lines = explode(PHP_EOL, $request->input('text'));

    $results = expmodel::whereIn('codemelli', $lines)->get();

    // Export results to Excel
    Excel::create('output', function ($excel) use ($results) {
        $excel->sheet('Sheet 1', function ($sheet) use ($results) {
            $sheet->fromArray($results);
        });
    })->download('xlsx');
}
}

  class SearchController extends Controller
  {
      public function index()
      {
          return view('search');
      }

      public function search(Request $request)
{
    $queries = explode("\n", $request->input('query'));

    $results = collect();

    foreach ($queries as $query) {
        $query = trim($query);

        if (!empty($query)) {
            $queryResults = YourModel::where('column_name', 'LIKE', "%$query%")->get(); // Replace with your actual column name and model

            $results = $results->concat($queryResults);
        }
    }

    Excel::create('search_results', function ($excel) use ($results) {
        $excel->sheet('Sheet 1', function ($sheet) use ($results) {
            $sheet->fromArray($results);
        });
    })->download('xlsx');
}
  }*/