<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class expmodel extends Model
{
    protected $table = 'lsvd'; // Replace with your actual table name

    protected $fillable = [
        'codemelli',
        'name',
        'famil',
        'other',
    ];
}