<!-- resources/views/create.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>افزودن رکورد</title>
    <style>
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .overlay-content {
            background-color: white;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="overlay-content">
    @if(session('success'))
        <div>{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('record.store') }}">
        @csrf
        <label for="codemelli">کد ملی:</label>
        <input type="text" name="codemelli" id="codemelli"><br>

        <label for="name">نام:</label>
        <input type="text" name="name" id="name"><br>

        <label for="famil">نام خانوادگی:</label>
        <input type="text" name="famil" id="famil"><br>

        <label for="other">توضیحات:</label>
        <input type="text" name="other" id="other"><br>

        <button type="submit">افزودن</button>
    </form>
</div>
</div>
</body>
</html>