<?php
namespace App\Http\Controllers;

use App\Models\Record;
use Illuminate\Http\Request;

class RecordController extends Controller
{
    public function create()
    {
        return view('create');
    }

    public function createOverlay()
    {
        return view('create-overlay');
    }


    public function store(Request $request)
    {
        $record = new Record;
        $record->codemelli = $request->input('codemelli');
        $record->name = $request->input('name');
        $record->famil = $request->input('famil');
        $record->other = $request->input('other');
        $record->save();

        return redirect()->route('record.create')->with('success', 'Record added successfully.');
       
    }
}

/*
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RecordController extends Controller
{
    //
}
*/