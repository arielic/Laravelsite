<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\srchctrl;


Route::get('/search', [srchctrl::class, 'index']);
Route::post('/search', [srchctrl::class, 'search']);
//Route::post('/search', [srchctrl::class, 'search']);


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|Route::get('/search', [srchctrl::class, 'index']);
Route::post('/search', [srchctrl::class, 'search']);



Route::get('/search', 'App\Http\Controllers\srchctrl@index');
Route::post('/search', 'App\Http\Controllers\srchctrl@search');


Route::get('/search', function () {
    return view('welcome');
});
*/