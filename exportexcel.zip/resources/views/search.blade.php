<!DOCTYPE html>
<html>
<head>
    <title>exports</title>
</head>
<body>

    <form action="/search" method="POST">
        @csrf
        <textarea name="query" placeholder="مقادیر را خط به خط وارد کنید"></textarea>
        <button type="submit">Search</button>
    </form>

    
</body>
</html>