<!-- resources/views/create.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Create Record</title>
</head>
<body>
    @if(session('success'))
        <div>{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('record.store') }}">
        @csrf
        <label for="codemelli">کد ملی:</label>
        <input type="text" name="codemelli" id="codemelli"><br>

        <label for="name">نام:</label>
        <input type="text" name="name" id="name"><br>

        <label for="famil">نام خانوادگی:</label>
        <input type="text" name="famil" id="famil"><br>

        <label for="other">توضیحات:</label>
        <input type="text" name="other" id="other"><br>

        <button type="submit">افزودن</button>
    </form>
</body>
</html>