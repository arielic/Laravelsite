<!DOCTYPE html>
<html>
    
    
<head>
    
    <title>Create Record</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
    <style>
        .overlay-link {
            cursor: pointer;
            color: red;
            
        }
    </style>
</head>


<body>
    <header>
        <div class="hamburger-menu">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </header>
    
    <div id="overlay" style="display: none;">
        <div id="overlay-content">
            <!-- Content of the overlay box -->
            <h2>Overlay Box</h2>
            <p>This is the content of the overlay box.</p>
            <button id="close-overlay">Close</button>
        </div>
    </div>
    @if(session('success'))
        <div>{{ session('success') }}</div>
    @endif
    <button id="open-overlay" onclick="open-overlay" type="button">Open Overlay</button>

    <p>دکمه افزودن رکورد <img src="addusr.png" class="overlay-link" onclick="openOverlay()" width="50" height="50"> </p>

    <script>
        function openOverlay() {
            window.open('{{ route('record.create.overlay') }}', 'Create Record', 'width=400,height=400');
        }
    </script>
</body>
<script src="{{ asset('js/overlay.js') }}"></script>
</html>