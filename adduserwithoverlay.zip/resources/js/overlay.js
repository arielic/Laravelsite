import './bootstrap';
document.querySelector('.hamburger-menu').addEventListener('click', function() {
    this.classList.toggle('open');
});
document.addEventListener('DOMContentLoaded', function() {
    var overlay = document.getElementById('overlay');
    var closeOverlay = document.getElementById('close-overlay');

    // Show the overlay box
    document.getElementById('open-overlay').addEventListener('click', function() {
        overlay.style.display = 'flex';
    });

    // Hide the overlay box
    closeOverlay.addEventListener('click', function() {
        overlay.style.display = 'none';
    });
});