
<!doctype html>
<html>
<head>
    <!-- Scripts    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a> -->
    
    
    <!-- Styles -->
    <link href="{{ asset('css/custom.css') }}" rel="stylesheet">
</head>
<body>
    <header>
        <div class="sidenav">
            <a href="#">About</a>
            <a href="#">Services</a>
            <a href="#">Clients</a>
            <a href="#">Contact</a>
          </div>
    <div id="mySidepanel" class="sidepanel">
        <button class="openbtn" onclick="openNav(this)" >&#9776;</button>
        
        <a href="#">خانه</a>
        <a href="#">خروجی لیست</a>
        <a href="#">افزودن رکورد</a>
        <a href="#">...</a>
        
      </div>
      
    
      
</body>
<script src="{{ asset('js/custom.js') }}" defer></script>
</html>
