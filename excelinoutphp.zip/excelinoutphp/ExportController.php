<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;

class ExportController extends Controller
{
    public function export()
{
    // Create new Spreadsheet object
    $spreadsheet = new Spreadsheet();

    // Get active sheet
    $sheet = $spreadsheet->getActiveSheet();
    // Set column headings
    $spreadsheet->getActiveSheet()
        ->setCellValue('A1', 'name')
        ->setCellValue('B1', 'codemelli')
        ->setCellValue('C1', 'famil')
        ->setCellValue('D1', 'other');

        $headerStyle = [
            'font' => [
                'bold' => true,
                'color' => ['rgb' => 'EBF0FF'],
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'A300A3'],
            ],
            
        ];
        $headerStyle2 = [
            'font' => [
                'bold' => true,
                'color' => ['rgb' => 'EBF0FF'],
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E680E6'],
            ],
            
        ];
        $columncolor = [
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'FAE6FA'],
            ],
            
        ];
    $sheet->getColumnDimension('A')->setWidth(20);
    $sheet->getColumnDimension('B')->setWidth(20);
    $sheet->getColumnDimension('C')->setWidth(20);
    $sheet->getColumnDimension('D')->setWidth(20);
    $sheet->getStyle('A')->applyFromArray($columncolor);
    $sheet->getStyle('C')->applyFromArray($columncolor);
    $sheet->getStyle('A1')->applyFromArray($headerStyle);
    $sheet->getStyle('C1')->applyFromArray($headerStyle);
    $sheet->getStyle('B1')->applyFromArray($headerStyle2);
    $sheet->getStyle('D1')->applyFromArray($headerStyle2);
    // Get data from the database
    $data = DB::table('lsvd')->get();

    // Set the data rows
    $row = 2;
    foreach ($data as $item) {
        $spreadsheet->getActiveSheet()
            ->setCellValue('A' . $row, $item->name)
            ->setCellValue('B' . $row, $item->codemelli)
            ->setCellValue('C' . $row, $item->famil)
            ->setCellValue('D' . $row, $item->other);
        $row++;
    }

    // Create a new Excel writer object
    $writer = new Xlsx($spreadsheet);

    // Set the headers for the file download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="export.xlsx"');
    header('Cache-Control: max-age=0');

    // Save the spreadsheet to a file
    $writer->save('php://output');
}
}