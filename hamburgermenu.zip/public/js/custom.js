var x=0;

function openNav() {
  document.getElementById("mySidepanel").style.width = "300px";
  if (x==0){
    document.getElementById("mySidepanel").style.width = "300px";
    x++;
  }
  else{
    document.getElementById("mySidepanel").style.width = "90px";
    x=0;
  }

}

/* Set the width of the sidebar to 0 (hide it) */
function closeNav() {
  document.getElementById("mySidepanel").style.width = "90px";
}

