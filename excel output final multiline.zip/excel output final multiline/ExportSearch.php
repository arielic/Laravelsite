<?php

namespace App\Http\Controllers;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;
class ExportSearch extends Controller
{
    public function export(Request $request)
{
    // Retrieve the input and split it into an array of lines
    $lines = explode("\n", $request->input);

    // Search for each line in the four columns of the database
    $results = DB::table('lsvd')
        ->whereIn('name', $lines)
        ->orWhereIn('codemelli', $lines)
        ->orWhereIn('famil', $lines)
        ->orWhereIn('other', $lines)
        ->get();

    // Create a new Excel file
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    $spreadsheet->getActiveSheet()
        ->setCellValue('A1', 'name')
        ->setCellValue('B1', 'codemelli')
        ->setCellValue('C1', 'famil')
        ->setCellValue('D1', 'other');

        $headerStyle = [
            'font' => [
                'bold' => true,
                'color' => ['rgb' => 'EBF0FF'],
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'A300A3'],
            ],
            
        ];
        $headerStyle2 = [
            'font' => [
                'bold' => true,
                'color' => ['rgb' => 'EBF0FF'],
            ],
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'E680E6'],
            ],
            
        ];
        $columncolor = [
            'fill' => [
                'fillType' => Fill::FILL_SOLID,
                'startColor' => ['rgb' => 'FAE6FA'],
            ],
            
        ];
    $sheet->getStyle('A')->applyFromArray($columncolor);
    $sheet->getStyle('C')->applyFromArray($columncolor);
    $sheet->getStyle('A1')->applyFromArray($headerStyle);
    $sheet->getStyle('C1')->applyFromArray($headerStyle);
    $sheet->getStyle('B1')->applyFromArray($headerStyle2);
    $sheet->getStyle('D1')->applyFromArray($headerStyle2);
    // Set the column width
    $sheet->getColumnDimension('A')->setWidth(20);
    $sheet->getColumnDimension('B')->setWidth(20);
    $sheet->getColumnDimension('C')->setWidth(20);
    $sheet->getColumnDimension('D')->setWidth(20);
    // Populate the Excel file with the search results
    $row = 2;
    foreach ($results as $result) {
        $sheet->setCellValue('A' . $row, $result->name);
        $sheet->setCellValue('B' . $row, $result->codemelli);
        $sheet->setCellValue('C' . $row, $result->famil);
        $sheet->setCellValue('D' . $row, $result->other);
        $row++;
    }

    // Save and download the Excel file
    $writer = new Xlsx($spreadsheet);
    $filename = 'export.xlsx';
    $writer->save($filename);

    return response()->download($filename)->deleteFileAfterSend(true);
}
}
